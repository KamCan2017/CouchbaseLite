﻿using System;

namespace CBLiteApplication
{
    public class BaseModel
    {
        public BaseModel()
        {
        }
        public Guid ID { get; set; }
    }
}
